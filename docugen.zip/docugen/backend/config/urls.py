from django.conf import settings
from django.conf.urls.static import static
from django.contrib import admin
from django.urls import include, path

urlpatterns = [
    path("admin/", admin.site.urls),
    path("api/company/", include("company.urls")),
    path("api/projects/", include("projects.urls")),
    path("api/documents/", include("documents.urls")),
    path("api/forms/", include("onlineforms.urls")),
    path("api/auth/", include("accounts.urls")),
    # Résolution publique des liens réduits : /s/<code>
    path("s/", include("onlineforms.short_urls")),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
